""""
说明：在这里我用到了一个手机的型号，参考价格，重量的 CSV 表，
其中：Mobile phone model表示手机型号
    Price表示参考价格
    weight表示重量
    details表示详情
    numerical表示对应的数值
"""
import pandas as pd
import numpy as np

#读取一个CSV表
df = pd.read_csv('./data1.csv')
print(df)

#通过将几个列折叠为两列来重新调整表
tmp=pd.melt(df,id_vars='Mobile phone model',var_name='details',value_name='numerical')

#将重塑后的数据写入标准输出
print(tmp)





